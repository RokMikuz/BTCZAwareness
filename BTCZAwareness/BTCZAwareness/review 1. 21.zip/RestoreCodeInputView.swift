import SwiftUI

struct RestoreCodeInputView: View {
    @State private var code: String = ""

    var body: some View {
        VStack {
            Text("Enter Restore Code")
                .font(.headline)
            TextField("Restore Code", text: $code)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            Button("Restore") {
                // Handle restore action
            }
            .disabled(code.isEmpty)
        }
        .padding()
    }
}
