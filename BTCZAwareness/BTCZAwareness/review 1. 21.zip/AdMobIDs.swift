import Foundation

struct AdMobIDs {
    // Live AdMob unit IDs
    static let rewarded = "ca-app-pub-5181471839265609/9052584196"
    static let banner = "ca-app-pub-5181471839265609/5152049399"
}
