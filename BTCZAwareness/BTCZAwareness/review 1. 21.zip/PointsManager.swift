// PointsManager.swift – 100 % CELOTNA – VARNA SINHRONIZACIJA + LOGI + PODPORA ZA CLICKER
import Foundation
import Combine
import UIKit

class PointsManager: ObservableObject {
    static let shared = PointsManager()
    
    @Published var currentPoints: Int = 0
    @Published var hasWallet: Bool = false
    @Published var referralCode: String = ""

    private var isSaving = false
    
    private let deviceID = UIDevice.current.identifierForVendor?.uuidString ?? "unknown_device"
    
    private init() {
        loadFromDisk()
        // print("PointsManager: device_id=\(ApiService.deviceID), baseURL=\(ApiService.baseURL)")
        ApiService.registerUserIfNeeded()
        syncWithServer()  // naloži iz serverja ob zagonu app-a
    }
    
    // NALOŽI TOČKE IZ SERVERJA (GET /points)
    func syncWithServer(completion: (() -> Void)? = nil) {
        print("PointsManager: syncWithServer – GET from server")
        print("PointsManager: calling \(ApiService.baseURL)/points?device_id=\(ApiService.deviceID)")
        ApiService.getPoints { [weak self] points in
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.currentPoints = points
                if points == 0 {
                    print("PointsManager WARNING: server returned 0 points (check device_id and server response)")
                }
                self.saveToDisk()
                print("PointsManager: loaded points from server: \(points)")
                completion?()
            }
        }
    }
    
    // PUBLIC: force refresh from server (server is the single source of truth)
    func refreshFromServer(completion: (() -> Void)? = nil) {
        syncWithServer(completion: completion)
    }
    
    // POŠLJI TOČKE NA SERVER (POST /api/sync-points) – VARNO
    func saveToServer(completion: (() -> Void)? = nil) {
        if isSaving {
            print("PointsManager: saveToServer skipped (already saving)")
            completion?()
            return
        }
        self.isSaving = true

        print("PointsManager: saveToServer – POST to \(ApiService.baseURL)/sync-points with points=\(currentPoints) and device_id=\(ApiService.deviceID)")
        ApiService.syncPoints(points: currentPoints) { success in
            DispatchQueue.main.async {
                self.isSaving = false
                if success {
                    print("PointsManager: points saved to server successfully")
                } else {
                    print("PointsManager: failed to save points to server")
                }
                completion?()
            }
        }
    }
    
    // DODAJ TOČKE LOKALNO + POŠLJI NA SERVER
    func addPoints(_ points: Int) {
        // NOTE: Do NOT use this for PvP or server-awarded rewards. Server must award and we only refresh.
        // This is intended for purely local/offline mini-activities that later sync their total.
        currentPoints += points
        saveToDisk()
        print("PointsManager: added \(points) points locally → tentative balance: \(currentPoints). Now syncing to server...")
        saveToServer()
    }
    
    // POSODOBI WALLET STATUS + POŠLJI NA SERVER
    func walletAdded() {
        hasWallet = true
        saveToDisk()
        saveToServer()
        NotificationCenter.default.post(name: .walletAdded, object: nil)
    }
    
    // NALOŽI IZ UserDefaults (backup če ni interneta)
    private func loadFromDisk() {
        currentPoints = UserDefaults.standard.integer(forKey: "currentPoints")
        hasWallet = UserDefaults.standard.bool(forKey: "hasWallet")
        referralCode = UserDefaults.standard.string(forKey: "referralCode") ?? ""
        print("PointsManager: loaded from disk – points: \(currentPoints), hasWallet: \(hasWallet)")
    }
    
    // SHRANI V UserDefaults (backup)
    private func saveToDisk() {
        UserDefaults.standard.set(currentPoints, forKey: "currentPoints")
        UserDefaults.standard.set(hasWallet, forKey: "hasWallet")
        UserDefaults.standard.set(referralCode, forKey: "referralCode")
    }
}

extension Notification.Name {
    static let walletAdded = Notification.Name("walletAdded")
}
