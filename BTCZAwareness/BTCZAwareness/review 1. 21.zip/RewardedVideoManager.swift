// RewardedVideoManager.swift – 100 % DELUJOČA, BREZ EXC_BAD_ACCESS
import GoogleMobileAds
import UIKit

@MainActor
class RewardedVideoManager: NSObject, FullScreenContentDelegate {
    private static let rewardedAdUnitId = AdMobIDs.rewarded
    
    static let shared = RewardedVideoManager()
    
    private var rewardedAd: RewardedAd?
    private var isLoading = false
    private var pendingCompletion: ((Bool, Error?) -> Void)?
    
    private override init() {
        super.init()
        loadAd()
    }
    
    func loadAd() {
        guard !isLoading else { return }
        isLoading = true
        
        RewardedAd.load(with: Self.rewardedAdUnitId, request: Request()) { [weak self] ad, error in
            // Hop to the main actor before mutating any @MainActor-isolated state
            Task { @MainActor in
                guard let self = self else { return }
                self.isLoading = false
                
                if let ad = ad {
                    print("Oglas naložen!")
                    self.rewardedAd = ad
                    self.rewardedAd?.fullScreenContentDelegate = self
                    
                    if let completion = self.pendingCompletion {
                        completion(false, NSError(domain: "RewardedVideoManager", code: -2, userInfo: [NSLocalizedDescriptionKey: "Ad loaded; waiting for presenter"]))
                        self.pendingCompletion = nil
                    }
                } else if let error = error {
                    print("Napaka pri nalaganju oglasa: \(error.localizedDescription)")
                    DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                        self.loadAd()
                    }
                }
            }
        }
    }
    
    func showAd(from presenter: UIViewController, completion: @escaping (Bool, Error?) -> Void) {
        if let ad = rewardedAd {
            presentAdIfReady(from: presenter, completion: completion)
        } else {
            print("Oglas še ni naložen – čakam...")
            pendingCompletion = { [weak self, weak presenter] success, error in
                guard let self = self, let presenter = presenter else { return }
                if success {
                    completion(true, nil)
                } else if let ad = self.rewardedAd {
                    self.presentAdIfReady(from: presenter, completion: completion)
                } else {
                    completion(false, error)
                }
            }
            loadAd()
        }
    }
    
    private func presentAdIfReady(from presenter: UIViewController, completion: @escaping (Bool, Error?) -> Void) {
        guard let ad = rewardedAd else {
            let error = NSError(domain: "RewardedVideoManager", code: -1, userInfo: [NSLocalizedDescriptionKey: "No ad loaded"])
            completion(false, error)
            return
        }
        
        print("Prikazujem oglas...")
        ad.present(from: presenter) {
            // Server reward call can be off-main, but UI/state updates are on main actor
            ApiService.rewardVideo { success, message, newPoints in
                DispatchQueue.main.async {
                    if success {
                        PointsManager.shared.currentPoints = newPoints ?? PointsManager.shared.currentPoints
                        print("Server: \(message ?? "Success!")")
                    } else {
                        print("Server error: \(message ?? "Unknown")")
                    }
                }
            }
            Task { @MainActor in
                self.loadAd()
                completion(true, nil)
            }
        }
    }
    
    func adDidDismissFullScreenContent(_ ad: FullScreenPresentingAd) {
        print("Oglas zaprt – ponovno nalagam")
        loadAd()
    }
    
    func ad(_ ad: FullScreenPresentingAd, didFailToPresentFullScreenContentWithError error: Error) {
        print("Napaka pri prikazu oglasa: \(error.localizedDescription)")
        pendingCompletion?(false, error)
        pendingCompletion = nil
        loadAd()
    }
}

